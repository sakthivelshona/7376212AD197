import { useState } from 'react'
import reactLogo from './assets/react.svg'
import viteLogo from '/vite.svg'
import './App.css'
import Newarrival from './Components/Newarrival'

function App() {

const comp = [{id:1,name:'Amazon'},{id:2,name:'Flipkart'},
{id:3,name:'Snapdeal'},{id:4,name:'Reliance'},{id:5,name:'Myntra'},
]

const cartitems = [
  {id:1,img:'https://m.media-amazon.com/images/I/71vFKBpKakL._SX522_.jpg',title:"Blood Pressure Monitor",price:"Rs.540"},
  {id:2,img:'https://m.media-amazon.com/images/I/71v2jVh6nIL._AC_UY327_FMwebp_QL65_.jpg',title:"Humidifying Unit for Home",price:"Rs.700"},
  {id:3,img:'lmns.jpg',title:"Olly Vitamin D3",price:"Rs.200"},
  {id:4,img:'oils.jpg',title:"Essential Oils",price:"Rs.565"}
]

  return (
    <>
      <div className='back'>
        <h1>Welcome to Affordmed </h1>
        <h3>
          Explore the top N products sold by your Dream Companies
        </h3>
      </div>

      <div className="searchb">
        <input type="search" id="sb" placeholder='Enter the company...' />
        <button id="search">Search</button>
      </div>

<h2>Top Companies</h2>

<div className="com">

  <div className="c1">Amazon</div>
  <div className="c1">Flipkart</div>
  <div className="c1">Myntra</div>
  <div className="c1">Ajio</div>
  <div className="c1">Snapdeal</div>

</div>
<h2>New Arrivals</h2>

{
  cartitems.map((i)=>{
    return(
      <Newarrival key={i.id} item={i}/>
    )
  })
}
    </>
  )
}

export default App
